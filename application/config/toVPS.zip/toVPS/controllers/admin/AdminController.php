<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AdminController extends MY_Controller
{
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->model('M_entreprise','entreprise');
	
	}
	function home()
	{
		/*$data = array(
			'sideBarre'=>$this->load->view('template/admin/sideBarre',array('actif'=>'demande-inscription'),true)

	);
		$this->load->view('template/admin/demande-inscription',$data);*/
		$this->load->library('Date_operations');

		$dteRectrutement=new Datetime('03-10-2020');
			
			$entrepriseData = $this->M_entreprise->entrepriseData($this->session->entreprise);
			$dtecurrentYEar = new DateTime('31-12-'.date('Y'));
			if($dteRectrutement->format('Y')==$dtecurrentYEar->format('Y'))
			{
				$reliquatGlobal = 0;
				$reliquatAnne = $this->date_operations->daysCalculator($dteRectrutement,new DateTime('31-12-'.date('Y')),false);
			}
			else
			{

				$reliquattoAnne = $this->date_operations->daysCalculator($dteRectrutement,new DateTime('31-12-'.$dteRectrutement->format('Y')),false);
				$reliquatGlobal = $reliquattoAnne+(date('Y')-$dteRectrutement->format('Y')-1)*365;
				$reliquatAnne = 365;
			}
			
			$reliquatGlobal  = round($reliquatGlobal*$entrepriseData['conge_annee']/365,1);
			$reliquatAnne = round($reliquatAnne*$entrepriseData['conge_annee']/365,1);
			echo $reliquatGlobal;
			echo '</br>';
			echo $reliquatAnne;
			
	}
	function entreprisesDemandes()
	{
		$dta = $this->entreprise->show('e.nom,e.numero,e.tel,e.ville,e.date_creation as date_demande,e.mail ,d.libelle as domaine, concat(emp.nom,\' \',emp.prenom) as administrateur',array('confirmed'=>'false'));
		echo json_encode($dta);
	}

}
?>