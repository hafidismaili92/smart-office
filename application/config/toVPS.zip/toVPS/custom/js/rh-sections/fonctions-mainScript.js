document.addEventListener('DOMContentLoaded', function() {

	$.getScript(BaseUrl+"assets/custom/js/rh-sections/gestion-Fonctions.js");
	$.getScript(BaseUrl+"assets/custom/js/rh-sections/gestion-Etablissements.js");
	$.getScript(BaseUrl+"assets/custom/js/rh-sections/gestion-Classes.js");

},false);
