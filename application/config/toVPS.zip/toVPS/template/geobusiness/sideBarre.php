<div class="sidebar " id="sidebar">
                <div class="sidebar-inner slimscroll">
                	<form action="search.html" class="mobile-view">
						<input class="form-control" type="text" placeholder="Search here">
						<button class="btn" type="button"><i class="fa fa-search"></i></button>
					</form>
					<div id="sidebar-menu" class="sidebar-menu">
						<div style="width: 100%;flex-grow: 1">
								<table id="geoAffaires-table" style="width:100%;">
									<thead>
										<tr>
											<th>numero</th>
											<th>title</th>
											<th>action</th>
											
										</tr>
									</thead>
									
								</table>
							</div>
						</div>
                </div>
            </div>